const quotes = [
    "The best way to predict the future is to create it. – Peter Drucker",
    "Life is what happens when you're busy making other plans. – John Lennon",
    "Get busy living or get busy dying. – Stephen King",
    "You only live once, but if you do it right, once is enough. – Mae West",
    "In the end, we only regret the chances we didn't take. – Lewis Carroll",
    "Life is either a daring adventure or nothing at all. – Helen Keller",
    "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment. – Ralph Waldo Emerson",
    "The only limit to our realization of tomorrow is our doubts of today. – Franklin D. Roosevelt"
];

function getRandomQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    document.getElementById('quote').textContent = quotes[randomIndex];
}

document.getElementById('new-quote').addEventListener('click', getRandomQuote);

// Load a random quote on page load
window.onload = getRandomQuote;
